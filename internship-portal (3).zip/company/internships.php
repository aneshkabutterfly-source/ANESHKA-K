<?php
session_start();
require_once "../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "company") {
    header("Location: ../login.php");
    exit();
}

$internships = [];
try {
    $stmt = $conn->query("SELECT * FROM internships ORDER BY id DESC");
    $internships = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $internships = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Internships - InternHub</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body { font-family: sans-serif; background: #0b0f19; color: #fff; margin: 0; min-height: 100vh; }
        .navbar { display: flex; justify-content: space-between; align-items: center; padding: 20px 60px; background: #0f172a; border-bottom: 1px solid #1e293b; }
        .brand { font-size: 22px; font-weight: bold; color: #fff; text-decoration: none; }
        .brand span { color: #38bdf8; }
        .nav-links { display: flex; gap: 20px; }
        .nav-links a { color: #94a3b8; text-decoration: none; font-size: 14px; transition: 0.2s; }
        .nav-links a:hover, .nav-links a.active { color: #38bdf8; }
        
        .container { max-width: 1000px; margin: 40px auto; padding: 0 20px; }
        .tagline { color: #38bdf8; font-size: 12px; font-weight: bold; letter-spacing: 1px; text-transform: uppercase; margin-bottom: 10px; }
        .page-title { font-size: 32px; font-weight: 800; margin-bottom: 30px; }
        
        .table-card { background: #0f172a; border: 1px solid #1e293b; border-radius: 12px; overflow: hidden; }
        table { width: 100%; border-collapse: collapse; text-align: left; }
        th { background: #182238; color: #94a3b8; padding: 15px 20px; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; }
        td { padding: 18px 20px; border-top: 1px solid #1e293b; font-size: 14px; color: #e2e8f0; }
        
        .badge { padding: 6px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; display: inline-block; background: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.3); }
        .btn-add { background: #38bdf8; color: #0f172a; padding: 10px 20px; border-radius: 6px; text-decoration: none; font-weight: bold; font-size: 14px; display: inline-block; margin-top: 15px; }
        .btn-add:hover { background: #0284c7; color: #fff; }
    </style>
</head>
<body>
    <nav class="navbar">
        <a class="brand" href="dashboard.php">Intern<span>Hub</span></a>
        <div class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="add_internship.php">Add Internship</a>
            <a href="applicants.php">Applicants</a>
            <a href="internships.php" class="active">Internships</a>
            <a href="../logout.php">Logout</a>
        </div>
    </nav>

    <div class="container">
        <div class="tagline">Posted Internships</div>
        <h1 class="page-title">All Posted Internships</h1>

        <div class="table-card">
            <?php if (!empty($internships)): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Company</th>
                            <th>Location</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($internships as $item): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($item['title'] ?? ''); ?></strong></td>
                                <td><?php echo htmlspecialchars($item['company'] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($item['location'] ?? ''); ?></td>
                                <td><span class="badge">Active</span></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div style="text-align: center; padding: 50px 20px;">
                    <p style="color: #94a3b8; margin-bottom: 10px;">No internships posted yet.</p>
                    <a href="add_internship.php" class="btn-add">Add New Internship</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>