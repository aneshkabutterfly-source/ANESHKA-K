<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

if (!isset($_SESSION["user_id"]) || ($_SESSION["role"] ?? '') !== 'company') {
    header("Location: ../login.php");
    exit();
}

$company_name = $_SESSION["name"] ?? "Company";

$json_path = __DIR__ . '/../config/db_data.json';
$json_data = file_exists($json_path) ? json_decode(file_get_contents($json_path), true) : [];

$internships = $json_data["internships"] ?? [];
$applications = $json_data["applications"] ?? [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Dashboard - InternHub</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body { font-family: sans-serif; background: #0b0f19; color: #fff; margin: 0; }
        .navbar { display: flex; justify-content: space-between; align-items: center; padding: 20px 40px; background: #0f172a; border-bottom: 1px solid #1e293b; }
        .brand { font-size: 22px; font-weight: bold; color: #fff; text-decoration: none; }
        .brand span { color: #38bdf8; }
        .nav-links a { color: #94a3b8; text-decoration: none; margin-left: 20px; }
        .nav-links a:hover { color: #fff; }
        .container { max-width: 1000px; margin: 40px auto; padding: 0 20px; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
        .header h1 { font-size: 32px; margin: 5px 0 0 0; }
        .badge { background: rgba(56, 189, 248, 0.1); color: #38bdf8; padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: bold; display: inline-block; }
        .btn-add { background: #38bdf8; color: #0f172a; padding: 12px 20px; border-radius: 8px; text-decoration: none; font-weight: bold; }
        .btn-add:hover { background: #0284c7; color: #fff; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; }
        .stat-card { background: #0f172a; border: 1px solid #1e293b; border-radius: 12px; padding: 24px; text-decoration: none; color: inherit; display: block; transition: transform 0.2s, border-color 0.2s; }
        .stat-card:hover { transform: translateY(-3px); border-color: #38bdf8; }
        .stat-card h3 { color: #94a3b8; font-size: 13px; margin: 0 0 10px 0; }
        .stat-card .number { font-size: 36px; font-weight: bold; color: #38bdf8; }
    </style>
</head>
<body>
    <nav class="navbar">
        <a class="brand" href="dashboard.php">Intern<span>Hub</span></a>
        <div class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="add_internship.php">Add Internship</a>
            <a href="internships.php">Internships</a>
            <a href="applicants.php">Applicants</a>
            <a href="../logout.php">Logout</a>
        </div>
    </nav>

    <main class="container">
        <div class="header">
            <div>
                <span class="badge">COMPANY DASHBOARD</span>
                <h1>Welcome, <?php echo htmlspecialchars($company_name); ?></h1>
            </div>
            <a href="add_internship.php" class="btn-add">+ Add Internship</a>
        </div>

        <div class="stats-grid">
            <a href="internships.php" class="stat-card">
                <h3>TOTAL INTERNSHIPS</h3>
                <div class="number"><?php echo count($internships); ?></div>
            </a>
            <a href="applicants.php" class="stat-card">
                <h3>TOTAL APPLICANTS</h3>
                <div class="number"><?php echo count($applications); ?></div>
            </a>
        </div>
    </main>
</body>
</html>