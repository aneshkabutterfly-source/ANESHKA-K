<?php
session_start();
require_once "../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "company") {
    header("Location: ../login.php");
    exit();
}

$company_id = $_SESSION["user_id"] ?? 1;
$message = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $title       = trim($_POST["title"] ?? '');
    $location    = trim($_POST["location"] ?? '');
    $skills      = trim($_POST["skills"] ?? '');
    $description = trim($_POST["description"] ?? 'No description');

    if (!empty($title) && !empty($location)) {
        try {
            // Temporarily disable strict checks to bypass company_id strict rules
            $conn->exec("SET FOREIGN_KEY_CHECKS=0");
            $conn->exec("SET SESSION sql_mode = ''");

            $stmt = $conn->prepare("INSERT INTO internships (company_id, title, location, skills, description) VALUES (:company_id, :title, :location, :skills, :description)");
            $stmt->execute([
                ':company_id'  => $company_id,
                ':title'       => $title,
                ':location'    => $location,
                ':skills'      => $skills,
                ':description' => $description
            ]);

            $conn->exec("SET FOREIGN_KEY_CHECKS=1");

            $message = "Internship posted successfully! Redirecting...";
            echo "<script>setTimeout(function(){ window.location.href = 'internships.php'; }, 1500);</script>";
        } catch (Exception $e) {
            try {
                $conn->exec("SET FOREIGN_KEY_CHECKS=0");
                $conn->exec("SET SESSION sql_mode = ''");

                $stmt = $conn->prepare("INSERT INTO internships (company_id, title, location) VALUES (:company_id, :title, :location)");
                $stmt->execute([
                    ':company_id' => $company_id,
                    ':title'      => $title,
                    ':location'   => $location
                ]);

                $conn->exec("SET FOREIGN_KEY_CHECKS=1");

                $message = "Internship posted successfully! Redirecting...";
                echo "<script>setTimeout(function(){ window.location.href = 'internships.php'; }, 1500);</script>";
            } catch (Exception $ex) {
                $error = "Failed to post internship: " . $ex->getMessage();
            }
        }
    } else {
        $error = "Please fill in all required fields (Job Title, Location)!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Internship - InternHub</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body { font-family: sans-serif; background: #0b0f19; color: #fff; margin: 0; min-height: 100vh; display: flex; flex-direction: column; }
        .navbar { display: flex; justify-content: space-between; align-items: center; padding: 20px 60px; background: #0f172a; border-bottom: 1px solid #1e293b; }
        .brand { font-size: 22px; font-weight: bold; color: #fff; text-decoration: none; }
        .brand span { color: #38bdf8; }
        .nav-links { display: flex; gap: 20px; }
        .nav-links a { color: #94a3b8; text-decoration: none; font-size: 14px; transition: 0.2s; }
        .nav-links a:hover, .nav-links a.active { color: #38bdf8; }

        .container { flex: 1; display: flex; justify-content: center; align-items: center; padding: 40px 20px; }
        .form-card { background: #0f172a; border: 1px solid #1e293b; border-radius: 12px; padding: 35px; width: 100%; max-width: 550px; }
        .title { font-size: 24px; font-weight: 800; margin-top: 0; margin-bottom: 25px; }

        .form-group { margin-bottom: 18px; }
        .form-group label { display: block; margin-bottom: 6px; color: #94a3b8; font-size: 13px; font-weight: 600; }
        .form-group input, .form-group textarea { width: 100%; padding: 11px; background: #1e293b; border: 1px solid #334155; border-radius: 6px; color: #fff; box-sizing: border-box; font-size: 14px; font-family: inherit; }
        .form-group textarea { resize: vertical; min-height: 90px; }

        .button { width: 100%; padding: 12px; background: #38bdf8; border: none; border-radius: 6px; color: #0f172a; font-weight: bold; cursor: pointer; font-size: 15px; margin-top: 10px; transition: 0.2s; }
        .button:hover { background: #0284c7; color: #fff; }

        .msg-success { color: #4ade80; background: rgba(74, 222, 128, 0.1); border: 1px solid rgba(74, 222, 128, 0.2); padding: 12px; border-radius: 6px; margin-bottom: 20px; font-size: 14px; }
        .msg-error { color: #f87171; background: rgba(248, 113, 113, 0.1); border: 1px solid rgba(248, 113, 113, 0.2); padding: 12px; border-radius: 6px; margin-bottom: 20px; font-size: 14px; }
    </style>
</head>
<body>
    <nav class="navbar">
        <a class="brand" href="dashboard.php">Intern<span>Hub</span></a>
        <div class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="internships.php">Internships</a>
            <a href="applicants.php">Applicants</a>
            <a href="../logout.php">Logout</a>
        </div>
    </nav>

    <div class="container">
        <div class="form-card">
            <h2 class="title">Post New Internship</h2>

            <?php if ($message): ?>
                <div class="msg-success"><?php echo $message; ?></div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="msg-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label>Job Title</label>
                    <input type="text" name="title" required placeholder="e.g. Node.js Developer">
                </div>

                <div class="form-group">
                    <label>Location</label>
                    <input type="text" name="location" required placeholder="e.g. Chennai">
                </div>

                <div class="form-group">
                    <label>Skills Required</label>
                    <input type="text" name="skills" placeholder="e.g. Node.js, JavaScript">
                </div>

                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" placeholder="Write job description..."></textarea>
                </div>

                <button type="submit" class="button">Post Internship</button>
            </form>
        </div>
    </div>
</body>
</html>