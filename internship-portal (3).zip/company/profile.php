<?php require '../config/database.php';guard('company');
if(post()){if(trim($_POST['name']??'')===''){flash('Name required','err');go('company/profile.php');}
  q('UPDATE companies SET name=?,industry=?,website=?,location=?,about=? WHERE user_id=?',[trim($_POST['name']),$_POST['industry'],$_POST['website'],$_POST['location'],$_POST['about'],me()]);$_SESSION['u']['name']=trim($_POST['name']);flash('Profile saved');go('company/profile.php');}
top('Company profile');$p=q('SELECT * FROM companies WHERE user_id=?',[me()])->fetch();?>
<h2>Company profile</h2><form method="post" class="card" data-validate><?=tok()?>
<?php foreach(['name'=>'Company name','industry'=>'Industry','website'=>'Website','location'=>'Location'] as $k=>$l)echo "<label>$l<input name='$k' value='".e($p[$k])."'></label>";?>
<label>About<textarea name="about" rows="4"><?=e($p['about'])?></textarea></label><button>Save profile</button></form><?php bottom();
