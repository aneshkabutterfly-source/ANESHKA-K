# College Internship Application Portal (PHP + MySQL)
## ByteXL setup
1. DB workspace: run database.sql in MySQL (creates database internship_portal and all tables).
2. PHP workspace: paste files as per the structure, then edit the 5 DB_* lines at top of config/database.php.
3. Start the PHP server and open index.php.
Admin (auto-created on first run): admin@college.edu / Admin@123
Company accounts need admin approval (Admin panel > Companies) before posting.
