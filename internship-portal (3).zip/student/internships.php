<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

$config_path = __DIR__ . "/../config/database.php";
if (file_exists($config_path)) {
    require_once $config_path;
}

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    header("Location: ../login.php");
    exit();
}

$search_query = trim($_GET['q'] ?? '');
$internships = [];

try {
    if (isset($conn) && $conn instanceof PDO) {
        if ($search_query !== '') {
            $stmt = $conn->prepare("
                SELECT i.*, u.name AS company_name 
                FROM internships i 
                LEFT JOIN users u ON i.company_id = u.id 
                WHERE i.title LIKE :q OR i.location LIKE :q OR i.description LIKE :q OR u.name LIKE :q
                ORDER BY i.id DESC
            ");
            $stmt->execute([':q' => "%$search_query%"]);
        } else {
            $stmt = $conn->query("
                SELECT i.*, u.name AS company_name 
                FROM internships i 
                LEFT JOIN users u ON i.company_id = u.id 
                ORDER BY i.id DESC
            ");
        }
        $internships = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (Exception $e) {
    $internships = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Internships - InternHub</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body { font-family: sans-serif; background: #0b0f19; color: #fff; margin: 0; }
        .navbar { display: flex; justify-content: space-between; align-items: center; padding: 20px 40px; background: #0f172a; border-bottom: 1px solid #1e293b; }
        .brand { font-size: 22px; font-weight: bold; color: #fff; text-decoration: none; }
        .brand span { color: #38bdf8; }
        .nav-links a { color: #94a3b8; text-decoration: none; margin-left: 20px; }
        .nav-links a:hover { color: #fff; }
        .container { max-width: 1100px; margin: 40px auto; padding: 0 20px; }
        .page-heading h1 { font-size: 32px; margin: 10px 0; }
        .page-heading p { color: #94a3b8; margin-bottom: 25px; }
        .search-box { display: flex; gap: 10px; margin-bottom: 35px; }
        .search-box input { flex: 1; padding: 12px 18px; background: #0f172a; border: 1px solid #1e293b; border-radius: 8px; color: #fff; font-size: 15px; }
        .search-box button { padding: 12px 25px; background: #38bdf8; border: none; border-radius: 8px; color: #0f172a; font-weight: bold; cursor: pointer; }
        .search-box button:hover { background: #0284c7; color: #fff; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 20px; }
        .card { background: #0f172a; border: 1px solid #1e293b; border-radius: 12px; padding: 24px; position: relative; }
        .badge { background: rgba(56, 189, 248, 0.1); color: #38bdf8; padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: bold; display: inline-block; }
        .location { position: absolute; top: 24px; right: 24px; color: #64748b; font-size: 14px; }
        .card h3 { font-size: 20px; margin: 15px 0 5px 0; color: #f8fafc; }
        .company { color: #38bdf8; font-weight: 600; margin-bottom: 15px; }
        .desc { color: #94a3b8; font-size: 14px; line-height: 1.5; margin-bottom: 20px; }
        .skills { font-size: 12px; color: #64748b; margin-bottom: 20px; }
        .button { display: inline-block; padding: 10px 20px; background: #38bdf8; color: #0f172a; border-radius: 6px; text-decoration: none; font-weight: bold; }
        .button:hover { background: #0284c7; color: #fff; }
    </style>
</head>
<body>
    <nav class="navbar">
        <a class="brand" href="dashboard.php">Intern<span>Hub</span></a>
        <div class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="profile.php">Profile</a>
            <a href="applications.php">Applications</a>
            <a href="../logout.php">Logout</a>
        </div>
    </nav>

    <main class="container">
        <div class="page-heading">
            <div class="badge">OPPORTUNITIES</div>
            <h1>Find Internships</h1>
            <p>Search for internships that match your skills and interests.</p>
        </div>

        <form class="search-box" method="GET" action="internships.php">
            <input type="text" name="q" placeholder="Search title, location or skills..." value="<?php echo htmlspecialchars($search_query); ?>">
            <button type="submit">Search</button>
        </form>

        <div class="grid">
            <?php if (!empty($internships)): ?>
                <?php foreach ($internships as $item): ?>
                    <div class="card">
                        <span class="badge"><?php echo htmlspecialchars($item["status"] ?? 'OPEN'); ?></span>
                        <span class="location"><?php echo htmlspecialchars($item["location"] ?? 'Remote'); ?></span>
                        <h3><?php echo htmlspecialchars($item["title"]); ?></h3>
                        <div class="company"><?php echo htmlspecialchars($item["company_name"] ?? $item["company"] ?? ''); ?></div>
                        <p class="desc"><?php echo htmlspecialchars($item["description"] ?? 'No description provided.'); ?></p>
                        <div class="skills"><?php echo htmlspecialchars($item["skills"] ?? ''); ?></div>
                        <a href="apply.php?id=<?php echo $item["id"]; ?>" class="button">Apply Now</a>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p style="color: #94a3b8;">No internships posted yet. Please add internships from a company account.</p>
            <?php endif; ?>
        </div>
    </main>
</body>
</html>