<?php
session_start();
@include_once "../config/database.php";

if (!isset($_SESSION["user_id"]) || strtolower($_SESSION["role"] ?? '') !== "student") {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION["user_id"];
$message = "";
$error = "";

// Initialize profile directly from current session variables
$profile = [
    "name"    => $_SESSION["name"] ?? '',
    "email"   => $_SESSION["email"] ?? '',
    "phone"   => $_SESSION["phone"] ?? '',
    "college" => $_SESSION["college"] ?? '',
    "course"  => $_SESSION["course"] ?? '',
    "skills"  => $_SESSION["skills"] ?? '',
    "resume"  => $_SESSION["resume"] ?? ''
];

// If database connection exists, fetch fresh database data for this specific user ID
if (isset($conn) && $conn instanceof mysqli && !$conn->connect_error) {
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    if ($stmt) {
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result && $row = $result->fetch_assoc()) {
            $profile = array_merge($profile, array_filter($row));
        }
        $stmt->close();
    }
}

// Handle Profile Update
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name    = trim($_POST["name"] ?? '');
    $email   = trim($_POST["email"] ?? '');
    $phone   = trim($_POST["phone"] ?? '');
    $college = trim($_POST["college"] ?? '');
    $course  = trim($_POST["course"] ?? '');
    $skills  = trim($_POST["skills"] ?? '');

    $resume_name = $profile["resume"];

    if (isset($_FILES["resume"]) && $_FILES["resume"]["error"] === UPLOAD_ERR_OK) {
        $upload_dir = "../uploads/";
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        $file_ext = pathinfo($_FILES["resume"]["name"], PATHINFO_EXTENSION);
        $resume_name = "resume_" . $user_id . "_" . time() . "." . $file_ext;
        move_uploaded_file($_FILES["resume"]["tmp_name"], $upload_dir . $resume_name);
    }

    // Update active Session
    $_SESSION["name"]    = $name;
    $_SESSION["email"]   = $email;
    $_SESSION["phone"]   = $phone;
    $_SESSION["college"] = $college;
    $_SESSION["course"]  = $course;
    $_SESSION["skills"]  = $skills;
    $_SESSION["resume"]  = $resume_name;

    // Update local profile array
    $profile["name"]    = $name;
    $profile["email"]   = $email;
    $profile["phone"]   = $phone;
    $profile["college"] = $college;
    $profile["course"]  = $course;
    $profile["skills"]  = $skills;
    $profile["resume"]  = $resume_name;

    // If database is active, update MySQL table as well
    if (isset($conn) && $conn instanceof mysqli && !$conn->connect_error) {
        $update_stmt = $conn->prepare("UPDATE users SET name = ?, email = ?, phone = ?, college = ?, course = ?, skills = ?, resume = ? WHERE id = ?");
        if ($update_stmt) {
            $update_stmt->bind_param("sssssssi", $name, $email, $phone, $college, $course, $skills, $resume_name, $user_id);
            $update_stmt->execute();
            $update_stmt->close();
        }
    }

    $message = "Profile updated successfully!";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - InternHub</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body { font-family: sans-serif; background: #0b0f19; color: #fff; margin: 0; }
        .navbar { display: flex; justify-content: space-between; align-items: center; padding: 20px 40px; background: #0f172a; border-bottom: 1px solid #1e293b; }
        .brand { font-size: 22px; font-weight: bold; color: #fff; text-decoration: none; }
        .brand span { color: #38bdf8; }
        .nav-links a { color: #94a3b8; text-decoration: none; margin-left: 20px; }
        .nav-links a:hover { color: #fff; }
        .container { max-width: 600px; margin: 40px auto; padding: 0 20px; }
        .card { background: #0f172a; border: 1px solid #1e293b; border-radius: 12px; padding: 30px; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; color: #94a3b8; font-size: 14px; }
        .form-group input { width: 100%; padding: 10px; background: #1e293b; border: 1px solid #334155; border-radius: 6px; color: #fff; box-sizing: border-box; }
        .button { width: 100%; padding: 12px; background: #38bdf8; border: none; border-radius: 6px; color: #0f172a; font-weight: bold; cursor: pointer; }
        .button:hover { background: #0284c7; color: #fff; }
        .msg-success { color: #4ade80; margin-bottom: 15px; }
        .msg-error { color: #f87171; margin-bottom: 15px; }
    </style>
</head>
<body>
    <nav class="navbar">
        <a class="brand" href="dashboard.php">Intern<span>Hub</span></a>
        <div class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="internships.php">Find Internships</a>
            <a href="applications.php">My Applications</a>
            <a href="profile.php">Profile</a>
            <a href="../logout.php">Logout</a>
        </div>
    </nav>

    <main class="container">
        <div class="card">
            <h2>My Profile</h2>
            <?php if ($message): ?><p class="msg-success"><?php echo htmlspecialchars($message); ?></p><?php endif; ?>
            <?php if ($error): ?><p class="msg-error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>

            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" name="name" value="<?php echo htmlspecialchars($profile["name"]); ?>" required>
                </div>
                <div class="form-group">
                    <label>Email Address</label>
                    <input type="email" name="email" value="<?php echo htmlspecialchars($profile["email"]); ?>" required>
                </div>
                <div class="form-group">
                    <label>Phone Number</label>
                    <input type="text" name="phone" value="<?php echo htmlspecialchars($profile["phone"]); ?>">
                </div>
                <div class="form-group">
                    <label>College Name</label>
                    <input type="text" name="college" value="<?php echo htmlspecialchars($profile["college"]); ?>">
                </div>
                <div class="form-group">
                    <label>Course / Branch</label>
                    <input type="text" name="course" value="<?php echo htmlspecialchars($profile["course"]); ?>">
                </div>
                <div class="form-group">
                    <label>Skills</label>
                    <input type="text" name="skills" value="<?php echo htmlspecialchars($profile["skills"]); ?>" placeholder="e.g. HTML, PHP, MySQL">
                </div>
                <div class="form-group">
                    <label>Upload Resume (PDF/Doc)</label>
                    <input type="file" name="resume" accept=".pdf,.doc,.docx">
                    <?php if (!empty($profile["resume"])): ?>
                        <p style="font-size: 12px; color: #94a3b8; margin-top: 5px;">
                            Current Resume: <a href="../uploads/<?php echo htmlspecialchars($profile["resume"]); ?>" target="_blank" style="color: #38bdf8;"><?php echo htmlspecialchars($profile["resume"]); ?></a>
                        </p>
                    <?php endif; ?>
                </div>
                <button type="submit" class="button">Update Profile</button>
            </form>
        </div>
    </main>
</body>
</html>