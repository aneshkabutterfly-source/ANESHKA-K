<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once "../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION["user_id"];
$student_name = $_SESSION["name"] ?? "Student";
$student_email = $_SESSION["email"] ?? "student@gmail.com";
$internship_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$message = "";
$error = "";

// Fetch Internship Details dynamically
$internship = null;
if ($internship_id > 0) {
    try {
        $stmt = $conn->prepare("
            SELECT i.*, u.name AS company_name 
            FROM internships i 
            LEFT JOIN users u ON i.company_id = u.id 
            WHERE i.id = :id
        ");
        $stmt->execute([':id' => $internship_id]);
        $internship = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        $error = "Error loading internship details.";
    }
}

// இண்டர்ன்ஷிப் ஐடி தவறாக இருந்தாலோ அல்லது கிடைக்கவில்லையோ internships.php பக்கத்திற்குத் திருப்பி அனுப்பிவிடும்
if (!$internship) {
    header("Location: internships.php");
    exit();
}

// Handle Form Submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name      = trim($_POST["name"] ?? '');
    $dept      = trim($_POST["department"] ?? '');
    $year      = trim($_POST["year"] ?? '');
    $course    = trim($_POST["course"] ?? '');
    $why_apply = trim($_POST["why_apply"] ?? '');

    if (!empty($name) && !empty($dept) && !empty($year) && !empty($course) && !empty($why_apply)) {
        try {
            $conn->exec("SET FOREIGN_KEY_CHECKS=0");

            // Check for existing application
            $check_stmt = $conn->prepare("SELECT id FROM applications WHERE student_id = :student_id AND internship_id = :internship_id");
            $check_stmt->execute([':student_id' => $user_id, ':internship_id' => $internship_id]);

            if ($check_stmt->fetch()) {
                $error = "You have already applied for this internship!";
            } else {
                // Insert Application
                $stmt = $conn->prepare("INSERT INTO applications (student_id, internship_id, status, applied_at) VALUES (:student_id, :internship_id, 'Under Review', NOW())");
                $stmt->execute([
                    ':student_id'   => $user_id,
                    ':internship_id'=> $internship_id
                ]);

                // Sync to students table if exists
                try {
                    $s_stmt = $conn->prepare("INSERT IGNORE INTO students (id, name, email) VALUES (:id, :name, :email)");
                    $s_stmt->execute([':id' => $user_id, ':name' => $name, ':email' => $student_email]);
                } catch (Exception $ex) {
                    // ignore secondary insert errors
                }

                $message = "Application submitted successfully! Redirecting...";
                echo "<script>setTimeout(function(){ window.location.href = 'applications.php'; }, 1500);</script>";
            }

            $conn->exec("SET FOREIGN_KEY_CHECKS=1");

        } catch (Exception $e) {
            $error = "Submission failed: " . $e->getMessage();
        }
    } else {
        $error = "Please fill in all required fields!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply Internship - InternHub</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body { font-family: sans-serif; background: #0b0f19; color: #fff; margin: 0; min-height: 100vh; display: flex; flex-direction: column; }
        .navbar { display: flex; justify-content: space-between; align-items: center; padding: 20px 60px; background: #0f172a; border-bottom: 1px solid #1e293b; }
        .brand { font-size: 22px; font-weight: bold; color: #fff; text-decoration: none; }
        .brand span { color: #38bdf8; }
        .nav-links { display: flex; gap: 20px; }
        .nav-links a { color: #94a3b8; text-decoration: none; font-size: 14px; transition: 0.2s; }
        .nav-links a:hover, .nav-links a.active { color: #38bdf8; }

        .container { flex: 1; display: flex; justify-content: center; align-items: center; padding: 40px 20px; }
        .form-card { background: #0f172a; border: 1px solid #1e293b; border-radius: 12px; padding: 35px; width: 100%; max-width: 500px; }
        .tagline { color: #38bdf8; font-size: 11px; font-weight: bold; letter-spacing: 1px; text-transform: uppercase; margin-bottom: 8px; }
        .title { font-size: 26px; font-weight: 800; margin-top: 0; margin-bottom: 5px; }
        .sub-title { color: #38bdf8; font-size: 13px; margin-bottom: 25px; }

        .form-group { margin-bottom: 18px; }
        .form-group label { display: block; margin-bottom: 6px; color: #94a3b8; font-size: 13px; font-weight: 600; }
        .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 11px; background: #1e293b; border: 1px solid #334155; border-radius: 6px; color: #fff; box-sizing: border-box; font-size: 14px; font-family: inherit; }
        .form-group textarea { resize: vertical; min-height: 90px; }
        .form-row { display: flex; gap: 15px; }
        .form-row .form-group { flex: 1; }

        .button { width: 100%; padding: 12px; background: #38bdf8; border: none; border-radius: 6px; color: #0f172a; font-weight: bold; cursor: pointer; font-size: 15px; margin-top: 10px; transition: 0.2s; }
        .button:hover { background: #0284c7; color: #fff; }

        .msg-success { color: #4ade80; background: rgba(74, 222, 128, 0.1); border: 1px solid rgba(74, 222, 128, 0.2); padding: 12px; border-radius: 6px; margin-bottom: 20px; font-size: 14px; }
        .msg-error { color: #f87171; background: rgba(248, 113, 113, 0.1); border: 1px solid rgba(248, 113, 113, 0.2); padding: 12px; border-radius: 6px; margin-bottom: 20px; font-size: 14px; }
    </style>
</head>
<body>
    <nav class="navbar">
        <a class="brand" href="dashboard.php">Intern<span>Hub</span></a>
        <div class="nav-links">
            <a href="internships.php">Internships</a>
            <a href="applications.php">Applications</a>
            <a href="../logout.php">Logout</a>
        </div>
    </nav>

    <div class="container">
        <div class="form-card">
            <div class="tagline">Application Form</div>
            <!-- உங்களது இண்டர்ன்ஷிப் தலைப்பு மட்டும் -->
            <h1 class="title"><?php echo htmlspecialchars($internship['title']); ?></h1>
            <!-- கம்பெனி பெயர் மற்றும் இருப்பிடம் மட்டும் -->
            <div class="sub-title">
                <?php echo htmlspecialchars($internship['company_name'] ?? $internship['company']); ?> 
                (<?php echo htmlspecialchars($internship['location']); ?>)
            </div>

            <?php if ($message): ?>
                <div class="msg-success"><?php echo $message; ?></div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="msg-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" name="name" value="<?php echo htmlspecialchars($student_name); ?>" required placeholder="Enter your full name">
                </div>

                <div class="form-group">
                    <label>Department</label>
                    <input type="text" name="department" required placeholder="e.g. Computer Science & Engineering">
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Year of Study</label>
                        <select name="year" required>
                            <option value="">Select Year</option>
                            <option value="1st Year">1st Year</option>
                            <option value="2nd Year">2nd Year</option>
                            <option value="3rd Year">3rd Year</option>
                            <option value="Final Year">Final Year</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Course / Degree</label>
                        <input type="text" name="course" required placeholder="e.g. B.E / B.Tech / B.Sc">
                    </div>
                </div>

                <div class="form-group">
                    <label>Why are you interested in this position?</label>
                    <textarea name="why_apply" required placeholder="Explain briefly why you want to join this internship..."></textarea>
                </div>

                <button type="submit" class="button">Submit Application</button>
            </form>
        </div>
    </div>
</body>
</html>