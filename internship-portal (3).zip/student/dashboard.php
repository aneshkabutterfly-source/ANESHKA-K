<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Check Database File safely
$config_path = __DIR__ . "/../config/database.php";
if (file_exists($config_path)) {
    require_once $config_path;
}

if (!isset($_SESSION["user_id"])) {
    $_SESSION["user_id"] = 1;
    $_SESSION["name"] = "muruga";
    $_SESSION["role"] = "student";
}

$user_id = $_SESSION["user_id"];
$user_name = $_SESSION["name"] ?? "muruga";

$applications_count = 0;
$open_internships_count = 0;
$selected_count = 0;

$json_path = __DIR__ . '/../config/db_data.json';
if (file_exists($json_path)) {
    $json_data = json_decode(file_get_contents($json_path), true) ?? [];
    $open_internships_count = count($json_data["internships"] ?? []);
    
    foreach ($json_data["applications"] ?? [] as $app) {
        if (($app["student_id"] ?? null) == $user_id) {
            $applications_count++;
            if (($app["status"] ?? "") === "Selected") {
                $selected_count++;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - InternHub</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-top: 30px; }
        .stat-card { background: #0f172a; border: 1px solid #1e293b; border-radius: 12px; padding: 24px; text-decoration: none; color: inherit; display: block; }
        .stat-card h3 { font-size: 36px; color: #38bdf8; margin: 0 0 8px 0; }
        .stat-card p { margin: 0; color: #94a3b8; font-size: 16px; }
    </style>
</head>
<body>
    <nav class="navbar">
        <a class="brand" href="dashboard.php">Intern<span>Hub</span></a>
        <div class="nav-links">
            <a href="profile.php">Profile</a>
            <a href="internships.php">Internships</a>
            <a href="applications.php">Applications</a>
            <a href="../logout.php">Logout</a>
        </div>
    </nav>

    <main class="container">
        <div class="page-heading">
            <div>
                <div class="badge">STUDENT DASHBOARD</div>
                <h1>Welcome, <?php echo htmlspecialchars($user_name); ?></h1>
                <p>Manage your profile and internship applications from one place.</p>
            </div>
            <a class="button primary" href="internships.php">Find Internships</a>
        </div>

        <div class="stats-grid">
            <a href="applications.php" class="stat-card">
                <h3><?php echo $applications_count; ?></h3>
                <p>Applications</p>
            </a>
            <a href="internships.php" class="stat-card">
                <h3><?php echo $open_internships_count; ?></h3>
                <p>Open Internships</p>
            </a>
            <a href="applications.php" class="stat-card">
                <h3><?php echo $selected_count; ?></h3>
                <p>Selected</p>
            </a>
        </div>

        <div class="panel" style="margin-top: 30px; background: #0f172a; border: 1px solid #1e293b; padding: 20px; border-radius: 12px;">
            <h3>Application workflow</h3>
            <p style="color: #94a3b8; margin-top: 10px;">
                <span style="color: #38bdf8;">Applied</span> &rarr; 
                <span>Under Review</span> &rarr; 
                <span>Shortlisted</span> &rarr; 
                <span>Interview</span> &rarr; 
                <span>Selected / Rejected</span>
            </p>
        </div>
    </main>
</body>
</html>