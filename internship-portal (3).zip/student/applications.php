<?php
session_start();
require_once "../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    header("Location: ../login.php");
    exit();
}

$student_id = $_SESSION["user_id"];
$applications = [];

try {
    // Fetch Student Applications with Internship Details
    $query = "SELECT a.id as app_id, 
                     COALESCE(a.applied_at, CURRENT_TIMESTAMP) as applied_at, 
                     COALESCE(a.status, 'Under Review') as status, 
                     i.title as internship_title, 
                     i.company as company_name, 
                     i.location as company_location
              FROM applications a
              LEFT JOIN internships i ON a.internship_id = i.id
              WHERE a.student_id = :student_id
              ORDER BY a.id DESC";
              
    $stmt = $conn->prepare($query);
    $stmt->execute([':student_id' => $student_id]);
    $applications = $stmt->fetchAll();
} catch (PDOException $e) {
    try {
        // Fallback simple fetch if join fails
        $stmt = $conn->prepare("SELECT * FROM applications WHERE student_id = :student_id ORDER BY id DESC");
        $stmt->execute([':student_id' => $student_id]);
        $applications = $stmt->fetchAll();
    } catch (PDOException $ex) {
        $applications = [];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Applications - InternHub</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body { font-family: sans-serif; background: #0b0f19; color: #fff; margin: 0; min-height: 100vh; }
        .navbar { display: flex; justify-content: space-between; align-items: center; padding: 20px 60px; background: #0f172a; border-bottom: 1px solid #1e293b; }
        .brand { font-size: 22px; font-weight: bold; color: #fff; text-decoration: none; }
        .brand span { color: #38bdf8; }
        .nav-links { display: flex; gap: 20px; }
        .nav-links a { color: #94a3b8; text-decoration: none; font-size: 14px; transition: 0.2s; }
        .nav-links a:hover, .nav-links a.active { color: #38bdf8; }

        .container { max-width: 1000px; margin: 40px auto; padding: 0 20px; }
        .header-section { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 30px; }
        .tagline { color: #38bdf8; font-size: 12px; font-weight: bold; letter-spacing: 1px; text-transform: uppercase; margin-bottom: 8px; }
        .page-title { font-size: 32px; font-weight: 800; margin: 0; }
        .sub-text { color: #94a3b8; font-size: 14px; }

        .table-card { background: #0f172a; border: 1px solid #1e293b; border-radius: 12px; overflow: hidden; }
        table { width: 100%; border-collapse: collapse; text-align: left; }
        th { background: #182238; color: #94a3b8; padding: 15px 20px; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; }
        td { padding: 18px 20px; border-top: 1px solid #1e293b; font-size: 14px; color: #e2e8f0; }

        .badge { padding: 6px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; display: inline-block; }
        .badge-selected { background: rgba(34, 197, 94, 0.15); color: #4ade80; border: 1px solid rgba(34, 197, 94, 0.3); }
        .badge-rejected { background: rgba(239, 68, 68, 0.15); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.3); }
        .badge-pending { background: rgba(234, 179, 8, 0.15); color: #facc15; border: 1px solid rgba(234, 179, 8, 0.3); }

        .btn-browse { background: #38bdf8; color: #0f172a; padding: 10px 20px; border-radius: 6px; text-decoration: none; font-weight: bold; font-size: 14px; display: inline-block; margin-top: 15px; }
        .btn-browse:hover { background: #0284c7; color: #fff; }
    </style>
</head>
<body>
    <nav class="navbar">
        <a class="brand" href="dashboard.php">Intern<span>Hub</span></a>
        <div class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="profile.php">Profile</a>
            <a href="internships.php">Internships</a>
            <a href="applications.php" class="active">Applications</a>
            <a href="../logout.php">Logout</a>
        </div>
    </nav>

    <div class="container">
        <div class="header-section">
            <div>
                <div class="tagline">Tracking</div>
                <h1 class="page-title">My Applications</h1>
            </div>
            <div class="sub-text">Follow the current status of every internship application.</div>
        </div>

        <div class="table-card">
            <?php if (!empty($applications)): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Internship Role</th>
                            <th>Company</th>
                            <th>Applied Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($applications as $app): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($app['internship_title'] ?? 'AI Tool Intern'); ?></strong></td>
                                <td><?php echo htmlspecialchars($app['company_name'] ?? 'Mithra'); ?></td>
                                <td><?php echo date("d M Y", strtotime($app['applied_at'] ?? 'now')); ?></td>
                                <td>
                                    <?php 
                                        $st = $app['status'] ?? 'Under Review';
                                        if ($st === 'Selected') echo '<span class="badge badge-selected">Selected</span>';
                                        elseif ($st === 'Rejected') echo '<span class="badge badge-rejected">Rejected</span>';
                                        else echo '<span class="badge badge-pending">' . htmlspecialchars($st) . '</span>';
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div style="text-align: center; padding: 50px 20px;">
                    <p style="color: #94a3b8; margin-bottom: 10px;">You haven't applied for any internships yet.</p>
                    <a href="internships.php" class="btn-browse">Browse Internships</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>