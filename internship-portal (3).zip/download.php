<?php // serves resumes only to the owner, admin, or a company the student applied to
require 'config/database.php';$id=(int)($_GET['id']??0);$u=$_SESSION['u']??null;if(!$u)go('login.php');
$ok=$u['role']==='admin'||($u['role']==='student'&&$u['id']==$id)||($u['role']==='company'&&q('SELECT 1 FROM applications a JOIN internships i ON i.id=a.internship_id WHERE a.student_id=? AND i.company_id=?',[$id,$u['id']])->fetch());
$f=q('SELECT resume FROM students WHERE user_id=?',[$id])->fetchColumn();
if(!$ok||!$f){http_response_code(404);exit('Not available');}
header('Content-Type: application/pdf');readfile(__DIR__.'/uploads/'.basename($f));
