<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
require_once "config/database.php";

$message = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name     = trim($_POST["name"] ?? '');
    $email    = trim($_POST["email"] ?? '');
    $password = trim($_POST["password"] ?? '');
    $role     = strtolower(trim($_POST["role"] ?? 'student'));

    if (!empty($name) && !empty($email) && !empty($password)) {
        if ($conn) {
            try {
                // Check if email already exists
                $check_stmt = $conn->prepare("SELECT id FROM users WHERE email = :email");
                $check_stmt->execute([':email' => $email]);
                
                if ($check_stmt->fetch()) {
                    $error = "This email is already registered!";
                } else {
                    // Insert new user
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES (:name, :email, :password, :role)");
                    $success = $stmt->execute([
                        ':name'     => $name,
                        ':email'    => $email,
                        ':password' => $hashed_password,
                        ':role'     => $role
                    ]);

                    if ($success) {
                        $message = "Registration successful! You can now <a href='login.php' style='color:#38bdf8;'>Sign In</a>.";
                    } else {
                        $error = "Failed to register. Please try again.";
                    }
                }
            } catch (PDOException $e) {
                $error = "Database Error: " . $e->getMessage();
            }
        } else {
            $error = "Unable to connect to MySQL database!";
        }
    } else {
        $error = "Please fill in all fields!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - InternHub</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body { font-family: sans-serif; background: #0b0f19; color: #fff; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }
        .auth-container { background: #0f172a; border: 1px solid #1e293b; padding: 35px; border-radius: 12px; width: 100%; max-width: 420px; }
        .auth-container h2 { margin-top: 0; font-size: 26px; }
        .form-group { margin-bottom: 18px; }
        .form-group label { display: block; margin-bottom: 6px; color: #94a3b8; font-size: 14px; }
        .form-group input, .form-group select { width: 100%; padding: 10px; background: #1e293b; border: 1px solid #334155; border-radius: 6px; color: #fff; box-sizing: border-box; font-size: 14px; }
        .button { width: 100%; padding: 12px; background: #38bdf8; border: none; border-radius: 6px; color: #0f172a; font-weight: bold; cursor: pointer; font-size: 15px; margin-top: 10px; }
        .button:hover { background: #0284c7; color: #fff; }
        .msg-success { color: #4ade80; margin-bottom: 15px; font-size: 14px; }
        .msg-error { color: #f87171; margin-bottom: 15px; font-size: 14px; }
        a { color: #38bdf8; text-decoration: none; }
    </style>
</head>
<body>
    <div class="auth-container">
        <h2>Create Account</h2>
        <?php if ($message): ?>
            <p class="msg-success"><?php echo $message; ?></p>
        <?php endif; ?>
        <?php if ($error): ?>
            <p class="msg-error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST" action="register.php">
            <div class="form-group">
                <label>Full Name</label>
                <input type="text" name="name" required placeholder="Enter your name">
            </div>
            <div class="form-group">
                <label>Email Address</label>
                <input type="email" name="email" required placeholder="Enter your email">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" required placeholder="Create a password">
            </div>
            <div class="form-group">
                <label>Account Type</label>
                <select name="role" required>
                    <option value="student">Student</option>
                    <option value="company">Company / Employer</option>
                </select>
            </div>
            <button type="submit" class="button">Register</button>
        </form>

        <p style="text-align: center; margin-top: 20px; color: #94a3b8; font-size: 14px;">
            Already have an account? <a href="login.php">Sign In</a>
        </p>
    </div>
</body>
</html>