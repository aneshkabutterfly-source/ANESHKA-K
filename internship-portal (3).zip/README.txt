INTERNHUB - COLLEGE INTERNSHIP APPLICATION PORTAL

1. DATABASE SETUP
-----------------
Create/import the database.sql file in MySQL.

The database name is:
internship_portal

If your MySQL server uses a different username/password,
edit:
config/database.php

2. PROJECT LOCATION
-------------------
Place the internship-portal folder inside your PHP server folder.

Example:
htdocs/internship-portal

3. START THE WEBSITE
--------------------
From the project folder, run:

php -S 0.0.0.0:8080

Then open:

http://localhost:8080

If using a different PHP server setup, use its normal project URL.

4. STUDENT WORKFLOW
-------------------
Register as Student
        |
        v
Login
        |
        v
Complete Profile
        |
        v
Search Internships
        |
        v
Apply
        |
        v
Track Application

Application statuses:
Applied
Under Review
Shortlisted
Interview
Selected / Rejected

5. COMPANY WORKFLOW
-------------------
Register as Company/Admin
        |
        v
Login
        |
        v
Add Internship
        |
        v
View Applicants
        |
        v
Update Application Status

6. IMPORTANT FILES
------------------
index.php                  Home page
login.php                  Login
register.php               Registration
logout.php                 Logout
config/database.php        MySQL connection

student/dashboard.php     Student dashboard
student/profile.php        Student profile + resume
student/internships.php    Search internships
student/apply.php          Apply to internship
student/applications.php  Track application

company/dashboard.php      Company dashboard
company/add_internship.php Add internship
company/internships.php    Company internships
company/applicants.php     Applicant management

css/style.css              Professional design
js/validation.js           Basic form validation
database.sql               Database structure

7. STATUS UPDATE
----------------
Company/Admin opens:
company/applicants.php

Select an application status:
Applied
Under Review
Shortlisted
Interview
Selected
Rejected

Press Update.

The student will see the new status in:
student/applications.php

8. FEATURES
------------
PHP
MySQL
Sessions
Authentication
CRUD
Relationships
JOIN queries
Forms
File upload
Search/filter
Application tracking
Responsive UI
