<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
require_once "../config/database.php";

// Admin button-ai click seithu varubavargalukku mattum admin dashboard anumatikkappadum, 
// aanal student/company direct-ah vanthaal thadukkappadum (role check)
if (!isset($_SESSION["user_id"]) || ($_SESSION["role"] ?? '') !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$admin_name = $_SESSION["name"] ?? "System Admin";
$view = $_GET['view'] ?? 'dashboard';
$role_filter = $_GET['role'] ?? '';

try {
    // Stats count
    $total_students = $conn->query("SELECT COUNT(*) FROM users WHERE role = 'student'")->fetchColumn();
    $total_companies = $conn->query("SELECT COUNT(*) FROM users WHERE role = 'company'")->fetchColumn();
    $total_internships = $conn->query("SELECT COUNT(*) FROM internships")->fetchColumn();
    $total_applications = $conn->query("SELECT COUNT(*) FROM applications")->fetchColumn();

    // Dynamic Table Data based on click
    if ($view === 'users' && !empty($role_filter)) {
        $stmt = $conn->prepare("SELECT * FROM users WHERE role = :role ORDER BY id DESC");
        $stmt->execute([':role' => $role_filter]);
        $table_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $table_title = ucfirst($role_filter) . "s List";
        $table_type = 'users';
    } elseif ($view === 'internships') {
        $stmt = $conn->query("SELECT * FROM internships ORDER BY id DESC");
        $table_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $table_title = "All Internships List";
        $table_type = 'internships';
    } elseif ($view === 'applications') {
        // Joining applications with users and internships to get proper names and titles
        $query = "SELECT a.id, u.name as student_name, i.title as internship_title, a.status 
                  FROM applications a 
                  LEFT JOIN users u ON a.student_id = u.id 
                  LEFT JOIN internships i ON a.internship_id = i.id 
                  ORDER BY a.id DESC";
        $stmt = $conn->query($query);
        $table_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $table_title = "All Applications List";
        $table_type = 'applications';
    } else {
        $stmt = $conn->query("SELECT * FROM users ORDER BY id DESC");
        $table_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $table_title = "Registered Users";
        $table_type = 'users';
    }

} catch (PDOException $e) {
    $total_students = 0;
    $total_companies = 0;
    $total_internships = 0;
    $total_applications = 0;
    $table_data = [];
    $table_title = "Registered Users";
    $table_type = 'users';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - InternHub</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body { font-family: sans-serif; background: #0b0f19; color: #fff; margin: 0; }
        .navbar { display: flex; justify-content: space-between; align-items: center; padding: 20px 40px; background: #0f172a; border-bottom: 1px solid #1e293b; position: relative; z-index: 10; }
        .brand { font-size: 22px; font-weight: bold; color: #fff; text-decoration: none; }
        .brand span { color: #38bdf8; }
        .nav-links { display: flex; gap: 20px; align-items: center; }
        .nav-links a { color: #94a3b8; text-decoration: none; font-size: 15px; font-weight: 600; padding: 8px 12px; border-radius: 6px; transition: 0.2s; }
        .nav-links a:hover { color: #fff; background: #1e293b; }
        .container { max-width: 1100px; margin: 40px auto; padding: 0 20px; }
        .welcome-header { margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; }
        .welcome-header h1 { font-size: 32px; margin: 5px 0 0 0; }
        .badge { background: rgba(56, 189, 248, 0.1); color: #38bdf8; padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: bold; display: inline-block; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; margin-bottom: 40px; }
        
        .stat-card { background: #0f172a; border: 1px solid #1e293b; border-radius: 12px; padding: 24px; text-decoration: none; display: block; transition: 0.2s; cursor: pointer; }
        .stat-card:hover { border-color: #38bdf8; transform: translateY(-3px); background: #131c31; }
        .stat-card h3 { color: #94a3b8; font-size: 13px; margin: 0 0 10px 0; }
        .stat-card .number { font-size: 32px; font-weight: bold; color: #38bdf8; }

        .table-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; }
        .btn-back { background: #1e293b; color: #38bdf8; border: 1px solid #334155; padding: 8px 16px; border-radius: 6px; text-decoration: none; font-weight: 600; font-size: 14px; }
        .btn-back:hover { background: #334155; color: #fff; }

        .table-card { background: #0f172a; border: 1px solid #1e293b; border-radius: 12px; overflow: hidden; margin-bottom: 40px; }
        table { width: 100%; border-collapse: collapse; text-align: left; }
        th { background: #1e293b; color: #94a3b8; font-size: 13px; font-weight: 600; padding: 16px 24px; }
        td { padding: 18px 24px; border-bottom: 1px solid #1e293b; color: #f8fafc; font-size: 15px; }
    </style>
</head>
<body>
    <nav class="navbar">
        <a class="brand" href="dashboard.php">Intern<span>Hub</span></a>
        <div class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="../logout.php">Logout</a>
        </div>
    </nav>

    <main class="container">
        <div class="welcome-header">
            <div>
                <span class="badge">SYSTEM ADMIN PANEL</span>
                <h1>Welcome, <?php echo htmlspecialchars($admin_name); ?></h1>
            </div>
            <?php if ($view !== 'dashboard'): ?>
                <a href="dashboard.php" class="btn-back">&larr; Back to Dashboard</a>
            <?php endif; ?>
        </div>

        <div class="stats-grid">
            <a href="dashboard.php?view=users&role=student" class="stat-card">
                <h3>TOTAL STUDENTS</h3>
                <div class="number"><?php echo $total_students; ?></div>
            </a>
            <a href="dashboard.php?view=users&role=company" class="stat-card">
                <h3>TOTAL COMPANIES</h3>
                <div class="number"><?php echo $total_companies; ?></div>
            </a>
            <a href="dashboard.php?view=internships" class="stat-card">
                <h3>TOTAL INTERNSHIPS</h3>
                <div class="number"><?php echo $total_internships; ?></div>
            </a>
            <a href="dashboard.php?view=applications" class="stat-card">
                <h3>TOTAL APPLICATIONS</h3>
                <div class="number"><?php echo $total_applications; ?></div>
            </a>
        </div>

        <div class="table-header">
            <h2><?php echo htmlspecialchars($table_title); ?></h2>
        </div>
        
        <div class="table-card">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <?php if ($table_type === 'applications'): ?>
                            <th>Student Name</th>
                            <th>Internship Title</th>
                            <th>Status</th>
                        <?php else: ?>
                            <th>Name / Details</th>
                            <th>Email / Info</th>
                            <th>Role / Status</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($table_data)): ?>
                        <?php foreach ($table_data as $row): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row["id"] ?? ''); ?></td>
                                <?php if ($table_type === 'applications'): ?>
                                    <td><?php echo htmlspecialchars($row["student_name"] ?? 'Unknown Student'); ?></td>
                                    <td><?php echo htmlspecialchars($row["internship_title"] ?? 'Unknown Internship'); ?></td>
                                    <td><span class="badge"><?php echo htmlspecialchars(strtoupper($row["status"] ?? 'PENDING')); ?></span></td>
                                <?php else: ?>
                                    <td><?php echo htmlspecialchars($row["name"] ?? $row["title"] ?? $row["company_name"] ?? 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($row["email"] ?? $row["description"] ?? 'N/A'); ?></td>
                                    <td>
                                        <span class="badge">
                                            <?php echo htmlspecialchars(strtoupper($row["role"] ?? $row["status"] ?? 'GENERAL')); ?>
                                        </span>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4" style="text-align: center; color: #94a3b8;">No records found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>