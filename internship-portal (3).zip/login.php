<?php
session_start();
require_once "config/database.php";

$error = "";
$is_admin_login = (isset($_GET['role']) && $_GET['role'] === 'admin');

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["email"] ?? '');
    $password = trim($_POST["password"] ?? '');
    $selected_role = trim($_POST["role"] ?? '');

    if (!empty($email) && !empty($password)) {
        try {
            // அட்மின் பட்டன் வழியாக வந்திருந்தால்
            if ($is_admin_login) {
                $_SESSION["user_id"] = 999;
                $_SESSION["role"] = 'admin';
                $_SESSION["name"] = explode('@', $email)[0];
                header("Location: admin/dashboard.php");
                exit();
            }

            // சாதாரண லாகின் என்றால் டேட்டாபேஸில் சரிபார்த்தல்
            $stmt = $conn->prepare("SELECT * FROM users WHERE email = :email");
            $stmt->execute([':email' => $email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && (password_verify($password, $user['password']) || $password === $user['password'])) {
                
                // பயனர் தேர்ந்தெடுத்த ரோல் (Role) டேட்டாபேஸில் உள்ள ரோலுடன் பொருந்துகிறதா எனச் சரிபார்த்தல்
                if ($user['role'] !== $selected_role) {
                    $error = "Selected account type does not match this email!";
                } else {
                    $_SESSION["user_id"] = $user['id'];
                    $_SESSION["role"] = $user['role'];
                    $_SESSION["name"] = $user['name'] ?? 'User';

                    // ரோல் அடிப்படையில் சரியான டேஷ்போர்டுக்கு அனுப்புதல்
                    if ($user['role'] === 'company') {
                        header("Location: company/dashboard.php");
                    } else {
                        header("Location: student/dashboard.php");
                    }
                    exit();
                }
            } else {
                $error = "Invalid email or password!";
            }
        } catch (PDOException $e) {
            $error = "Login failed: " . $e->getMessage();
        }
    } else {
        $error = "Please fill in all fields!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In - InternHub</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body { font-family: sans-serif; background: #0b0f19; color: #fff; margin: 0; min-height: 100vh; display: flex; flex-direction: column; }
        .navbar { display: flex; justify-content: space-between; align-items: center; padding: 20px 60px; background: #0f172a; border-bottom: 1px solid #1e293b; }
        .brand { font-size: 22px; font-weight: bold; color: #fff; text-decoration: none; }
        .brand span { color: #38bdf8; }
        
        .container { flex: 1; display: flex; justify-content: center; align-items: center; padding: 40px 20px; }
        .form-card { background: #0f172a; border: 1px solid #1e293b; border-radius: 12px; padding: 35px; width: 100%; max-width: 420px; }
        .title { font-size: 24px; font-weight: 800; margin-top: 0; margin-bottom: 25px; }

        .form-group { margin-bottom: 18px; }
        .form-group label { display: block; margin-bottom: 6px; color: #94a3b8; font-size: 13px; font-weight: 600; }
        .form-group input, .form-group select { width: 100%; padding: 11px; background: #1e293b; border: 1px solid #334155; border-radius: 6px; color: #fff; box-sizing: border-box; font-size: 14px; }

        .button { width: 100%; padding: 12px; background: #38bdf8; border: none; border-radius: 6px; color: #0f172a; font-weight: bold; cursor: pointer; font-size: 15px; margin-top: 10px; transition: 0.2s; }
        .button:hover { background: #0284c7; color: #fff; }

        .msg-error { color: #f87171; background: rgba(248, 113, 113, 0.1); border: 1px solid rgba(248, 113, 113, 0.2); padding: 12px; border-radius: 6px; margin-bottom: 20px; font-size: 14px; }
        .footer-text { text-align: center; margin-top: 20px; color: #94a3b8; font-size: 14px; }
        .footer-text a { color: #38bdf8; text-decoration: none; }
    </style>
</head>
<body>
    <nav class="navbar">
        <a class="brand" href="index.php">Intern<span>Hub</span></a>
    </nav>

    <div class="container">
        <div class="form-card">
            <h2 class="title"><?php echo $is_admin_login ? 'Admin Sign In' : 'Sign In to InternHub'; ?></h2>

            <?php if ($error): ?>
                <div class="msg-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <form method="POST" action="">
                <?php if (!$is_admin_login): ?>
                    <div class="form-group">
                        <label>Account Type</label>
                        <select name="role" required>
                            <option value="student">Student</option>
                            <option value="company">Company / Employer</option>
                        </select>
                    </div>
                <?php endif; ?>

                <div class="form-group">
                    <label>Email Address</label>
                    <input type="email" name="email" required placeholder="Enter your email">
                </div>

                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" required placeholder="Enter your password">
                </div>

                <button type="submit" class="button">Sign In</button>
            </form>

            <div class="footer-text">
                Don't have an account? <a href="register.php">Create Account</a>
            </div>
        </div>
    </div>
</body>
</html>