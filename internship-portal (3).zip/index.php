<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>InternHub - College Internship Portal</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body { font-family: sans-serif; background: #0b0f19; color: #fff; margin: 0; min-height: 100vh; display: flex; flex-direction: column; }
        .navbar { display: flex; justify-content: space-between; align-items: center; padding: 20px 60px; background: #0f172a; border-bottom: 1px solid #1e293b; }
        .brand { font-size: 22px; font-weight: bold; color: #fff; text-decoration: none; }
        .brand span { color: #38bdf8; }
        .nav-links { display: flex; gap: 15px; align-items: center; }
        .btn-signup { background: #1e293b; color: #fff; border: 1px solid #334155; padding: 8px 16px; border-radius: 6px; text-decoration: none; font-size: 14px; font-weight: 600; transition: 0.2s; }
        .btn-signup:hover { background: #334155; }
        .btn-admin { background: transparent; color: #38bdf8; border: 1px solid #38bdf8; padding: 8px 16px; border-radius: 6px; text-decoration: none; font-size: 14px; font-weight: 600; transition: 0.2s; }
        .btn-admin:hover { background: rgba(56, 189, 248, 0.1); }

        .hero-section { display: flex; justify-content: space-between; align-items: center; padding: 60px; max-width: 1200px; margin: auto; flex: 1; gap: 40px; }
        .hero-content { max-width: 600px; }
        .hero-tag { color: #38bdf8; font-size: 12px; font-weight: bold; letter-spacing: 1px; text-transform: uppercase; margin-bottom: 15px; }
        .hero-title { font-size: 48px; font-weight: 800; line-height: 1.1; margin-bottom: 20px; }
        .hero-desc { color: #94a3b8; font-size: 16px; line-height: 1.6; margin-bottom: 30px; }
        
        .hero-actions { display: flex; gap: 15px; }
        .btn-get-started { background: #38bdf8; color: #0f172a; padding: 12px 24px; border-radius: 6px; text-decoration: none; font-weight: bold; font-size: 15px; transition: 0.2s; }
        .btn-get-started:hover { background: #0284c7; color: #fff; }

        .btn-signin-hero { background: #1e293b; color: #fff; border: 1px solid #334155; padding: 12px 24px; border-radius: 6px; text-decoration: none; font-weight: bold; font-size: 15px; transition: 0.2s; }
        .btn-signin-hero:hover { background: #334155; color: #38bdf8; }

        .journey-card { background: #0f172a; border: 1px solid #1e293b; border-radius: 12px; padding: 25px; width: 350px; }
        .journey-title { color: #38bdf8; font-size: 12px; font-weight: bold; letter-spacing: 1px; text-transform: uppercase; margin-bottom: 20px; }
        .journey-step { background: #182238; border: 1px solid #283548; padding: 12px 15px; border-radius: 8px; margin-bottom: 10px; font-size: 14px; display: flex; align-items: center; gap: 12px; }
        .step-num { background: #38bdf8; color: #0f172a; width: 24px; height: 24px; border-radius: 50%; display: flex; justify-content: center; align-items: center; font-weight: bold; font-size: 12px; }
    </style>
</head>
<body>
    <nav class="navbar">
        <a class="brand" href="index.php">Intern<span>Hub</span></a>
        <div class="nav-links">
            <!-- அட்மின் பட்டன் மட்டும் பிரத்யேகமாக மாற்றப்பட்டுள்ளது -->
            <a href="login.php?role=admin" class="btn-admin">Admin</a>
            <a href="register.php" class="btn-signup">Create Account</a>
        </div>
    </nav>

    <div class="hero-section">
        <div class="hero-content">
            <div class="hero-tag">College Internship Application Portal</div>
            <h1 class="hero-title">Find your next opportunity.</h1>
            <p class="hero-desc">A simple and professional platform for students to discover internships, apply online, and track every stage of their application.</p>
            
            <div class="hero-actions">
                <a href="login.php" class="btn-get-started">Get Started</a>
                <a href="login.php" class="btn-signin-hero">Sign In</a>
            </div>
        </div>

        <div class="journey-journey journey-card">
            <div class="journey-title">Application Journey</div>
            <div class="journey-step"><div class="step-num">1</div><div><strong>Applied</strong><br><span style="color: #94a3b8; font-size: 12px;">Application submitted</span></div></div>
            <div class="journey-step"><div class="step-num">2</div><div><strong>Under Review</strong><br><span style="color: #94a3b8; font-size: 12px;">Company is reviewing</span></div></div>
            <div class="journey-step"><div class="step-num">3</div><div><strong>Shortlisted</strong><br><span style="color: #94a3b8; font-size: 12px;">Selected for next stage</span></div></div>
            <div class="journey-step"><div class="step-num">4</div><div><strong>Interview</strong><br><span style="color: #94a3b8; font-size: 12px;">Interview stage</span></div></div>
            <div class="journey-step"><div class="step-num">5</div><div><strong>Selected</strong><br><span style="color: #94a3b8; font-size: 12px;">Final result</span></div></div>
        </div>
    </div>
</body>
</html>