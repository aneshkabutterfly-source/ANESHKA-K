<?php
$host = "db01.dbhost.dev";
$user = "user_455jwqduv";
$pass = "p455jwqduv";
$dbname = "db_455jwqduv";
$port = 5051;

try {
    $conn = new PDO("mysql:host=$host;port=$port;dbname=$dbname;charset=utf8", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("MySQL Connection Error: " . $e->getMessage());
}
?>